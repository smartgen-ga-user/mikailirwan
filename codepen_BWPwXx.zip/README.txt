A Pen created at CodePen.io. You can find this one at http://codepen.io/Miki17/pen/BWPwXx.

 